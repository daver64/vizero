#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("42\n");
    return 0;
}
